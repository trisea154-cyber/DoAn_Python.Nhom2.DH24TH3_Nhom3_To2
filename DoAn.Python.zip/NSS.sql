-- 1. Xóa database cũ đi để tránh lỗi trùng lặp
DROP DATABASE IF EXISTS hr_management;

-- 2. Tạo lại database mới tinh
CREATE DATABASE hr_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hr_management;

-- 3. Tạo lại các bảng
CREATE TABLE phongban (
    MaPB VARCHAR(20) PRIMARY KEY,
    TenPB VARCHAR(100) NOT NULL,
    DiaChi VARCHAR(200),
    SDT VARCHAR(20)
);

CREATE TABLE chucvu (
    MaCV VARCHAR(20) PRIMARY KEY,
    TenCV VARCHAR(100) NOT NULL,
    PhuCap DECIMAL(18,2) DEFAULT 0
);

CREATE TABLE nhanvien (
    MaNV VARCHAR(20) PRIMARY KEY,
    TenNV VARCHAR(100) NOT NULL,
    GioiTinh VARCHAR(10),
    NgaySinh DATE,
    DiaChi VARCHAR(200),
    DienThoai VARCHAR(20),
    MaPB VARCHAR(20),
    MaCV VARCHAR(20),
    TenDangNhap VARCHAR(50) UNIQUE, -- Cột này quan trọng để đăng nhập
    MatKhau VARCHAR(50),
    VaiTro VARCHAR(20) DEFAULT 'User',
    FOREIGN KEY (MaPB) REFERENCES phongban(MaPB) ON DELETE SET NULL,
    FOREIGN KEY (MaCV) REFERENCES chucvu(MaCV) ON DELETE SET NULL
);

CREATE TABLE hopdong (
    SoHD VARCHAR(20) PRIMARY KEY,
    MaNV VARCHAR(20),
    LoaiHD VARCHAR(50),
    NgayBatDau DATE,
    NgayKetThuc DATE,
    GhiChu TEXT,
    FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV) ON DELETE CASCADE
);

CREATE TABLE bangluong (
    MaLuong VARCHAR(20) PRIMARY KEY,
    MaNV VARCHAR(20),
    Thang INT,
    Nam INT,
    LuongCoBan DECIMAL(18,2),
    NgayCong INT,
    Thuong DECIMAL(18,2),
    Phat DECIMAL(18,2),
    ThucLanh DECIMAL(18,2),
    FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV) ON DELETE CASCADE
);

-- 4. Thêm tài khoản Admin (QUAN TRỌNG)
INSERT INTO phongban VALUES ('PB00', 'Ban Giám Đốc', 'Tầng 1', '0000');
INSERT INTO chucvu VALUES ('CV00', 'Admin', 0);
INSERT INTO nhanvien (MaNV, TenNV, MaPB, MaCV, TenDangNhap, MatKhau, VaiTro)
VALUES ('ADMIN', 'Quản Trị Viên', 'PB00', 'CV00', 'admin', 'admin', 'Admin');
USE hr_management;

-- 1. Xóa dữ liệu cũ (để tránh lỗi trùng lặp nếu chạy nhiều lần)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE bangluong;
TRUNCATE TABLE hopdong;
TRUNCATE TABLE nhanvien;
TRUNCATE TABLE chucvu;
TRUNCATE TABLE phongban;
SET FOREIGN_KEY_CHECKS = 1;

-- 2. Thêm Phòng Ban
INSERT INTO phongban (MaPB, TenPB, DiaChi, SDT) VALUES 
('PB01', 'Ban Giám Đốc', 'Tầng 5', '0901111111'),
('PB02', 'Phòng Nhân Sự', 'Tầng 2', '0902222222'),
('PB03', 'Phòng Kế Toán', 'Tầng 2', '0903333333'),
('PB04', 'Phòng IT - Kỹ Thuật', 'Tầng 3', '0904444444'),
('PB05', 'Phòng Kinh Doanh', 'Tầng 4', '0905555555');

-- 3. Thêm Chức Vụ
INSERT INTO chucvu (MaCV, TenCV, PhuCap) VALUES 
('CV01', 'Tổng Giám Đốc', 10000000),
('CV02', 'Trưởng Phòng', 5000000),
('CV03', 'Phó Phòng', 3000000),
('CV04', 'Nhân Viên Chính Thức', 1000000),
('CV05', 'Thực Tập Sinh', 500000);

-- 4. Thêm Nhân Viên (Lưu ý: Admin mật khẩu là admin, User mật khẩu là 123)
INSERT INTO nhanvien (MaNV, TenNV, GioiTinh, NgaySinh, DiaChi, DienThoai, MaPB, MaCV, TenDangNhap, MatKhau, VaiTro) VALUES 
('NV01', 'Nguyễn Văn Admin', 'Nam', '1990-01-01', 'Hà Nội', '0988888888', 'PB01', 'CV01', 'admin', 'admin', 'Admin'),
('NV02', 'Trần Thị Thư Ký', 'Nữ', '1995-05-20', 'Đà Nẵng', '0977777777', 'PB02', 'CV02', 'thuky', '123', 'User'),
('NV03', 'Lê Văn Code', 'Nam', '1998-12-10', 'TP.HCM', '0966666666', 'PB04', 'CV04', 'coder', '123', 'User'),
('NV04', 'Phạm Thị Kế Toán', 'Nữ', '1992-08-15', 'Hải Phòng', '0955555555', 'PB03', 'CV02', 'ketoan', '123', 'User'),
('NV05', 'Hoàng Văn Sale', 'Nam', '1996-03-30', 'Cần Thơ', '0944444444', 'PB05', 'CV04', 'sale01', '123', 'User'),
('NV06', 'Đỗ Thị Hạnh', 'Nữ', '2000-01-01', 'Hà Nội', '0933333333', 'PB02', 'CV04', 'hanhdt', '123', 'User'),
('NV07', 'Vũ Văn Hùng', 'Nam', '1993-07-22', 'Nghệ An', '0922222222', 'PB04', 'CV03', 'hungvv', '123', 'User'),
('NV08', 'Ngô Lan Anh', 'Nữ', '1997-11-11', 'Huế', '0911111111', 'PB05', 'CV04', 'lananh', '123', 'User'),
('NV09', 'Bùi Đức Thắng', 'Nam', '1999-09-09', 'Thanh Hóa', '0900000000', 'PB04', 'CV05', 'thangbd', '123', 'User'),
('NV10', 'Lý Thị Mơ', 'Nữ', '2001-02-14', 'Sapa', '0899999999', 'PB02', 'CV05', 'molt', '123', 'User');

-- 5. Thêm Hợp Đồng
INSERT INTO hopdong (SoHD, MaNV, LoaiHD, NgayBatDau, NgayKetThuc, GhiChu) VALUES 
('HD01', 'NV01', 'Vô thời hạn', '2020-01-01', NULL, 'Hợp đồng sếp'),
('HD02', 'NV02', '3 Năm', '2022-01-01', '2025-01-01', 'Hợp đồng chính thức'),
('HD03', 'NV03', '1 Năm', '2023-06-01', '2024-06-01', 'Hợp đồng thử việc xong'),
('HD04', 'NV04', '3 Năm', '2021-05-05', '2024-05-05', 'Tái ký lần 1');

-- 6. Thêm Bảng Lương (Tháng 11/2024)
INSERT INTO bangluong (MaLuong, MaNV, Thang, Nam, LuongCoBan, NgayCong, Thuong, Phat, ThucLanh) VALUES 
('L01', 'NV01', 11, 2024, 50000000, 26, 5000000, 0, 55000000),
('L02', 'NV02', 11, 2024, 15000000, 26, 1000000, 0, 16000000),
('L03', 'NV03', 11, 2024, 20000000, 24, 500000, 200000, 18900000),
('L04', 'NV04', 11, 2024, 18000000, 26, 2000000, 0, 20000000),
('L05', 'NV05', 11, 2024, 12000000, 25, 3000000, 0, 14500000);

UPDATE nhanvien SET TenNV = 'Quản Trị Viên' WHERE MaNV = 'ADMIN';