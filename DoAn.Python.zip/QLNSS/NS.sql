-- 1. Xóa database cũ đi để tránh lỗi trùng lặp
DROP DATABASE IF EXISTS hr_management;

-- 2. Tạo lại database mới tinh
CREATE DATABASE hr_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hr_management;

-- 3. Tạo lại các bảng
CREATE TABLE phongban (
    MaPB VARCHAR(20) PRIMARY KEY,
    TenPB VARCHAR(100) NOT NULL,
    DiaChi VARCHAR(200),
    SDT VARCHAR(20)
);

CREATE TABLE chucvu (
    MaCV VARCHAR(20) PRIMARY KEY,
    TenCV VARCHAR(100) NOT NULL,
    PhuCap DECIMAL(18,2) DEFAULT 0
);

CREATE TABLE nhanvien (
    MaNV VARCHAR(20) PRIMARY KEY,
    TenNV VARCHAR(100) NOT NULL,
    GioiTinh VARCHAR(10),
    NgaySinh DATE,
    DiaChi VARCHAR(200),
    DienThoai VARCHAR(20),
    MaPB VARCHAR(20),
    MaCV VARCHAR(20),
    TenDangNhap VARCHAR(50) UNIQUE, -- Cột này quan trọng để đăng nhập
    MatKhau VARCHAR(50),
    VaiTro VARCHAR(20) DEFAULT 'User',
    FOREIGN KEY (MaPB) REFERENCES phongban(MaPB) ON DELETE SET NULL,
    FOREIGN KEY (MaCV) REFERENCES chucvu(MaCV) ON DELETE SET NULL
);

CREATE TABLE hopdong (
    SoHD VARCHAR(20) PRIMARY KEY,
    MaNV VARCHAR(20),
    LoaiHD VARCHAR(50),
    NgayBatDau DATE,
    NgayKetThuc DATE,
    GhiChu TEXT,
    FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV) ON DELETE CASCADE
);

CREATE TABLE bangluong (
    MaLuong VARCHAR(20) PRIMARY KEY,
    MaNV VARCHAR(20),
    Thang INT,
    Nam INT,
    LuongCoBan DECIMAL(18,2),
    NgayCong INT,
    Thuong DECIMAL(18,2),
    Phat DECIMAL(18,2),
    ThucLanh DECIMAL(18,2),
    FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV) ON DELETE CASCADE
);

-- 4. Thêm tài khoản Admin (QUAN TRỌNG)
INSERT INTO phongban VALUES ('PB00', 'Ban Giám Đốc', 'Tầng 1', '0000');
INSERT INTO chucvu VALUES ('CV00', 'Admin', 0);
INSERT INTO nhanvien (MaNV, TenNV, MaPB, MaCV, TenDangNhap, MatKhau, VaiTro)
VALUES ('ADMIN', 'Quản Trị Viên', 'PB00', 'CV00', 'admin', 'admin', 'Admin');