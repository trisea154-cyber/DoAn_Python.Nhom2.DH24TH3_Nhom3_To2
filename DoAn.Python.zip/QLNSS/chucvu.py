import tkinter as tk
from tkinter import ttk, messagebox
from database import fetch_all, execute_query


class ChucVuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#ecf0f1")
        self.controller = controller

        # --- FORM NHẬP LIỆU ---
        frm = tk.LabelFrame(self, text="Quản lý Chức vụ", bg="white", padx=15, pady=15)
        frm.pack(fill="x", pady=(0, 10))

        tk.Label(frm, text="Mã CV (*):", bg="white").grid(row=0, column=0, sticky="w")
        self.txt_ma = tk.Entry(frm, width=15);
        self.txt_ma.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(frm, text="Tên CV (*):", bg="white").grid(row=0, column=2, sticky="w")
        self.txt_ten = tk.Entry(frm, width=25);
        self.txt_ten.grid(row=0, column=3, padx=10, pady=5)

        tk.Label(frm, text="Phụ Cấp (VNĐ):", bg="white").grid(row=0, column=4, sticky="w")
        self.txt_pc = tk.Entry(frm, width=15);
        self.txt_pc.insert(0, "0");
        self.txt_pc.grid(row=0, column=5, padx=10, pady=5)

        # Buttons
        btn_box = tk.Frame(frm, bg="white")
        btn_box.grid(row=1, columnspan=6, pady=10)

        tk.Button(btn_box, text="Làm mới", bg="#95a5a6", fg="white", width=10, command=self.clear).pack(side="left",
                                                                                                        padx=5)
        tk.Button(btn_box, text="Thêm", bg="#2980b9", fg="white", width=10, command=self.them).pack(side="left", padx=5)
        tk.Button(btn_box, text="Sửa", bg="#f39c12", fg="white", width=10, command=self.sua).pack(side="left", padx=5)
        tk.Button(btn_box, text="Xóa", bg="#c0392b", fg="white", width=10, command=self.xoa).pack(side="left", padx=5)

        # --- TABLE ---
        self.tree = ttk.Treeview(self, columns=("Ma", "Ten", "PC"), show="headings")
        self.tree.heading("Ma", text="Mã CV");
        self.tree.column("Ma", width=100)
        self.tree.heading("Ten", text="Tên Chức Vụ");
        self.tree.column("Ten", width=250)
        self.tree.heading("PC", text="Phụ Cấp (VNĐ)");
        self.tree.column("PC", anchor="e")
        self.tree.pack(fill="both", expand=True)

        # SỰ KIỆN CLICK
        self.tree.bind("<<TreeviewSelect>>", self.get_row)

    def load_data(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in fetch_all("SELECT * FROM chucvu"):
            # Format tiền có dấu phẩy
            self.tree.insert("", "end", values=(r['MaCV'], r['TenCV'], f"{r['PhuCap']:,.0f}"))

    def get_row(self, event):
        try:
            sel = self.tree.selection()
            if not sel: return
            item = self.tree.item(sel[0])['values']

            self.clear()
            self.txt_ma.insert(0, item[0])
            self.txt_ma.config(state='disabled')  # Không sửa mã
            self.txt_ten.insert(0, item[1])
            # Xóa dấu phẩy khi đưa lại vào ô nhập (ví dụ: 1,000,000 -> 1000000)
            pc_str = str(item[2]).replace(",", "")
            self.txt_pc.insert(0, pc_str)
        except:
            pass

    def clear(self):
        self.txt_ma.config(state='normal')
        self.txt_ma.delete(0, tk.END)
        self.txt_ten.delete(0, tk.END)
        self.txt_pc.delete(0, tk.END);
        self.txt_pc.insert(0, "0")
        self.txt_ma.focus()

    def validate(self):
        if not self.txt_ma.get().strip() or not self.txt_ten.get().strip():
            messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập Mã và Tên chức vụ!")
            return False
        try:
            float(self.txt_pc.get())
        except ValueError:
            messagebox.showerror("Lỗi", "Phụ cấp phải là số!")
            return False
        return True

    def them(self):
        if not self.validate(): return

        # Check trùng
        if fetch_all("SELECT * FROM chucvu WHERE MaCV=%s", (self.txt_ma.get(),)):
            messagebox.showerror("Lỗi", "Mã chức vụ đã tồn tại!")
            return

        if execute_query("INSERT INTO chucvu VALUES(%s,%s,%s)",
                         (self.txt_ma.get(), self.txt_ten.get(), self.txt_pc.get())):
            self.load_data();
            self.clear();
            messagebox.showinfo("OK", "Đã thêm chức vụ")

    def sua(self):
        if not self.txt_ma.get(): return
        if not self.validate(): return

        if execute_query("UPDATE chucvu SET TenCV=%s, PhuCap=%s WHERE MaCV=%s",
                         (self.txt_ten.get(), self.txt_pc.get(), self.txt_ma.get())):
            self.load_data();
            self.clear();
            messagebox.showinfo("OK", "Đã cập nhật")

    def xoa(self):
        sel = self.tree.selection()
        if sel and messagebox.askyesno("Xác nhận", "Xóa chức vụ này?"):
            if execute_query("DELETE FROM chucvu WHERE MaCV=%s", (self.tree.item(sel[0])['values'][0],)):
                self.load_data();
                self.clear()