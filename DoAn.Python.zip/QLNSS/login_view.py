import tkinter as tk
from tkinter import messagebox
from database import dang_nhap


class LoginApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("HRM System Login")
        self.root.geometry("400x500")
        self.root.configure(bg="#ecf0f1")

        # Căn giữa màn hình
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - 400) // 2
        y = (screen_height - 500) // 2
        self.root.geometry(f"400x500+{x}+{y}")

        # Header
        header = tk.Frame(self.root, bg="#2c3e50", height=150)
        header.pack(fill="x")
        tk.Label(header, text="HUMAN RESOURCE\nMANAGEMENT", font=("Helvetica", 18, "bold"),
                 bg="#2c3e50", fg="white").place(relx=0.5, rely=0.5, anchor="center")

        # Form Frame
        frm = tk.Frame(self.root, bg="white", padx=20, pady=20)
        frm.place(relx=0.5, rely=0.4, anchor="n", width=350, height=250)

        # Username
        tk.Label(frm, text="Tên đăng nhập", bg="white", fg="#7f8c8d", font=("Arial", 10)).pack(anchor="w")
        self.entry_user = tk.Entry(frm, font=("Arial", 12), bd=0, bg="#ecf0f1")
        self.entry_user.pack(fill="x", pady=5, ipady=5)

        # Password
        tk.Label(frm, text="Mật khẩu", bg="white", fg="#7f8c8d", font=("Arial", 10)).pack(anchor="w", pady=(10, 0))
        self.entry_pass = tk.Entry(frm, font=("Arial", 12), show="•", bd=0, bg="#ecf0f1")
        self.entry_pass.pack(fill="x", pady=5, ipady=5)

        # Button
        tk.Button(frm, text="ĐĂNG NHẬP", font=("Arial", 11, "bold"), bg="#2980b9", fg="white",
                  relief="flat", cursor="hand2", command=self.check_login).pack(fill="x", pady=20, ipady=5)

        self.root.bind('<Return>', lambda e: self.check_login())
        self.root.mainloop()

    def check_login(self):
        u = self.entry_user.get()
        p = self.entry_pass.get()
        user = dang_nhap(u, p)
        if user:
            self.root.destroy()
            import main
            main.HRMApp(user)
        else:
            messagebox.showerror("Lỗi", "Sai thông tin đăng nhập!")


if __name__ == "__main__":
    LoginApp()