import tkinter as tk
from tkinter import ttk, messagebox
from database import fetch_all, execute_query


class BangLuongPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#ecf0f1")
        self.controller = controller

        # --- KHUNG NHẬP LIỆU (FORM) ---
        frm = tk.LabelFrame(self, text="Tính toán lương tháng", bg="white", font=("Arial", 10, "bold"), padx=10,
                            pady=10)
        frm.pack(fill="x", pady=(0, 10))

        # Dòng 1: Mã phiếu và Nhân viên
        tk.Label(frm, text="Mã Phiếu (*):", bg="white").grid(row=0, column=0, sticky="w")
        self.e_ma = tk.Entry(frm, width=15, font=("Arial", 10))
        self.e_ma.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(frm, text="Nhân viên (*):", bg="white").grid(row=0, column=2, sticky="w")
        self.cb_nv = ttk.Combobox(frm, state="readonly", width=25, font=("Arial", 10))
        self.cb_nv.grid(row=0, column=3, padx=5, pady=5)

        # Dòng 2: Số liệu lương
        tk.Label(frm, text="Lương CB:", bg="white").grid(row=1, column=0, sticky="w")
        self.e_lcb = tk.Entry(frm, width=15);
        self.e_lcb.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(frm, text="Ngày công:", bg="white").grid(row=1, column=2, sticky="w")
        self.e_nc = tk.Entry(frm, width=10);
        self.e_nc.grid(row=1, column=3, padx=5, pady=5)

        tk.Label(frm, text="Thưởng:", bg="white").grid(row=1, column=4, sticky="w")
        self.e_thuong = tk.Entry(frm, width=15);
        self.e_thuong.insert(0, "0")
        self.e_thuong.grid(row=1, column=5, padx=5, pady=5)

        # Dòng 3: Các nút chức năng (Buttons)
        btn_box = tk.Frame(frm, bg="white")
        btn_box.grid(row=2, columnspan=6, pady=(15, 0))

        # Nút Làm mới
        tk.Button(btn_box, text="⟳ Làm mới", command=self.clear,
                  bg="#95a5a6", fg="white", width=12).pack(side="left", padx=5)

        # Nút Thêm (Tính & Lưu)
        tk.Button(btn_box, text="✚ TÍNH & LƯU", command=self.them,
                  bg="#27ae60", fg="white", font=("Arial", 10, "bold"), width=15).pack(side="left", padx=5)

        # Nút Sửa
        tk.Button(btn_box, text="✎ CẬP NHẬT", command=self.sua,
                  bg="#f39c12", fg="white", font=("Arial", 10, "bold"), width=12).pack(side="left", padx=5)

        # Nút Xóa
        tk.Button(btn_box, text="✖ XÓA PHIẾU", command=self.xoa,
                  bg="#c0392b", fg="white", font=("Arial", 10, "bold"), width=12).pack(side="left", padx=5)

        # --- BẢNG DỮ LIỆU (TREEVIEW) ---
        self.tree = ttk.Treeview(self, columns=("Ma", "Ten", "LCB", "NC", "Thuong", "Thuc"), show="headings", height=12)

        self.tree.heading("Ma", text="Mã Phiếu");
        self.tree.column("Ma", width=80, anchor="center")
        self.tree.heading("Ten", text="Tên Nhân Viên");
        self.tree.column("Ten", width=200)
        self.tree.heading("LCB", text="Lương Cơ Bản");
        self.tree.column("LCB", anchor="e", width=120)
        self.tree.heading("NC", text="Ngày Công");
        self.tree.column("NC", anchor="center", width=80)
        self.tree.heading("Thuong", text="Thưởng");
        self.tree.column("Thuong", anchor="e", width=100)
        self.tree.heading("Thuc", text="THỰC LĨNH (VNĐ)");
        self.tree.column("Thuc", anchor="e", width=150)

        self.tree.pack(fill="both", expand=True)

        # Sự kiện click vào bảng
        self.tree.bind("<<TreeviewSelect>>", self.get_row)

        self.nv_map = {}

    def load_data(self):
        # Load danh sách nhân viên vào Combobox
        nvs = fetch_all("SELECT MaNV, TenNV FROM nhanvien")
        self.nv_map = {f"{r['TenNV']} ({r['MaNV']})": r['MaNV'] for r in nvs}
        self.cb_nv['values'] = list(self.nv_map.keys())

        # Load dữ liệu bảng lương
        for i in self.tree.get_children(): self.tree.delete(i)

        sql = """SELECT b.MaLuong, n.TenNV, b.LuongCoBan, b.NgayCong, b.Thuong, b.ThucLanh, n.MaNV 
                 FROM bangluong b 
                 JOIN nhanvien n ON b.MaNV = n.MaNV
                 ORDER BY b.MaLuong DESC"""  # Sắp xếp mới nhất lên đầu

        for r in fetch_all(sql):
            # Format số tiền có dấu phẩy ngăn cách
            lcb_fmt = f"{r['LuongCoBan']:,.0f}"
            thuong_fmt = f"{r['Thuong']:,.0f}"
            thuc_fmt = f"{r['ThucLanh']:,.0f}"

            self.tree.insert("", "end",
                             values=(r['MaLuong'], r['TenNV'], lcb_fmt, r['NgayCong'], thuong_fmt, thuc_fmt, r['MaNV']))

    def get_row(self, event):
        try:
            sel = self.tree.selection()
            if not sel: return
            vals = self.tree.item(sel[0])['values']
            # vals: 0=Ma, 1=Ten, 2=LCB, 3=NC, 4=Thuong, 5=Thuc, 6=MaNV (ẩn)

            self.clear()
            self.e_ma.insert(0, vals[0])
            self.e_ma.config(state='disabled')  # Khóa mã phiếu lại để không sửa lung tung

            # Map lại tên nhân viên vào combobox
            target_ma_nv = str(vals[6])  # Lấy mã NV từ cột ẩn
            for k, v in self.nv_map.items():
                if v == target_ma_nv:
                    self.cb_nv.set(k)
                    break

            # Xóa dấu phẩy tiền tệ trước khi đưa vào ô nhập (VD: "1,000,000" -> "1000000")
            self.e_lcb.insert(0, str(vals[2]).replace(",", ""))
            self.e_nc.insert(0, vals[3])
            self.e_thuong.insert(0, str(vals[4]).replace(",", ""))

        except IndexError:
            pass

    def clear(self):
        self.e_ma.config(state='normal')  # Mở khóa để nhập mới
        self.e_ma.delete(0, tk.END)
        self.cb_nv.set('')
        self.e_lcb.delete(0, tk.END)
        self.e_nc.delete(0, tk.END)
        self.e_thuong.delete(0, tk.END);
        self.e_thuong.insert(0, "0")
        self.e_ma.focus()

    def get_and_validate_input(self):
        """Hàm phụ trợ: Lấy dữ liệu và kiểm tra lỗi, tự động tính Thực Lĩnh"""
        ma_phieu = self.e_ma.get().strip()
        nhan_vien = self.cb_nv.get()

        if not ma_phieu or not nhan_vien:
            messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập Mã phiếu và chọn Nhân viên!")
            return None

        try:
            lcb = float(self.e_lcb.get())
            nc = int(self.e_nc.get())
            thuong = float(self.e_thuong.get())

            if lcb < 0 or nc < 0 or thuong < 0:
                messagebox.showerror("Lỗi logic", "Số tiền và ngày công không được âm!")
                return None

            # CÔNG THỨC TÍNH LƯƠNG
            thuc_lanh = (lcb / 26 * nc) + thuong

            ma_nv = self.nv_map.get(nhan_vien)
            return (ma_phieu, ma_nv, lcb, nc, thuong, thuc_lanh)

        except ValueError:
            messagebox.showerror("Lỗi nhập liệu", "Lương, Ngày công, Thưởng phải là số hợp lệ!")
            return None

    def them(self):
        data = self.get_and_validate_input()
        if not data: return

        # Kiểm tra trùng mã phiếu
        check = fetch_all("SELECT * FROM bangluong WHERE MaLuong=%s", (data[0],))
        if check:
            messagebox.showerror("Trùng lặp", f"Mã phiếu '{data[0]}' đã tồn tại! Vui lòng chọn mã khác.")
            return

        # Thực hiện Thêm
        sql = "INSERT INTO bangluong(MaLuong, MaNV, LuongCoBan, NgayCong, Thuong, ThucLanh) VALUES(%s, %s, %s, %s, %s, %s)"
        if execute_query(sql, data):
            self.load_data()
            self.clear()
            messagebox.showinfo("Thành công", f"Đã lưu phiếu lương.\nThực lĩnh: {data[5]:,.0f} VNĐ")

    def sua(self):
        # Kiểm tra xem có đang chọn dòng nào không hoặc mã có bị trống không
        if self.e_ma.cget('state') == 'normal':
            messagebox.showwarning("Chú ý", "Bạn đang ở chế độ Thêm mới. Hãy chọn một dòng trong bảng để Sửa.")
            return

        data = self.get_and_validate_input()  # data[0] là Mã Phiếu
        if not data: return

        # Thực hiện Update
        sql = """UPDATE bangluong 
                 SET MaNV=%s, LuongCoBan=%s, NgayCong=%s, Thuong=%s, ThucLanh=%s 
                 WHERE MaLuong=%s"""
        # Đảo thứ tự params cho khớp với SQL: MaNV, LCB, NC, Thuong, ThucLanh, MaLuong (ở cuối)
        params = (data[1], data[2], data[3], data[4], data[5], data[0])

        if execute_query(sql, params):
            self.load_data()
            self.clear()
            messagebox.showinfo("Thành công", f"Đã cập nhật phiếu {data[0]}.\nThực lĩnh mới: {data[5]:,.0f} VNĐ")

    def xoa(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Vui lòng chọn phiếu lương cần xóa trên bảng!")
            return

        ma_phieu = self.tree.item(sel[0])['values'][0]
        ten_nv = self.tree.item(sel[0])['values'][1]

        if messagebox.askyesno("Xác nhận xóa", f"Bạn có chắc muốn xóa phiếu lương của:\n{ten_nv} (Mã: {ma_phieu})?"):
            if execute_query("DELETE FROM bangluong WHERE MaLuong=%s", (ma_phieu,)):
                self.load_data()
                self.clear()
                messagebox.showinfo("Đã xóa", "Đã xóa phiếu lương thành công!")