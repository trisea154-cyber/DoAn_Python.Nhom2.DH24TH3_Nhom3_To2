import mysql.connector
from mysql.connector import Error

def get_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='1234',  # <--- ĐIỀN PASS MYSQL CỦA BẠN
            database='hr_management',
            charset='utf8mb4'
        )
        return connection
    except Error as e:
        print("Lỗi kết nối:", e)
        return None

def fetch_all(query, params=None):
    conn = get_connection()
    if not conn: return []
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(query, params or ())
        return cur.fetchall()
    except Error as e:
        print(f"Lỗi truy vấn: {e}")
        return []
    finally:
        if conn.is_connected(): conn.close()

def execute_query(query, params=None):
    conn = get_connection()
    if not conn: return False
    try:
        cur = conn.cursor()
        cur.execute(query, params or ())
        conn.commit()
        return True
    except Error as e:
        print(f"Lỗi thực thi: {e}")
        return False
    finally:
        if conn.is_connected(): conn.close()

def dang_nhap(ten, mk):
    conn = get_connection()
    if not conn: return None
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM nhanvien WHERE TenDangNhap=%s AND MatKhau=%s", (ten, mk))
        return cur.fetchone()
    finally:
        if conn.is_connected(): conn.close()