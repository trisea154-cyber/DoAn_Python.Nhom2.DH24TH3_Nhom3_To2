import tkinter as tk
from tkinter import ttk, messagebox
from database import fetch_all, execute_query


class PhongBanPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#ecf0f1")
        self.controller = controller

        # Layout
        container = tk.Frame(self, bg="#ecf0f1")
        container.pack(fill="both", expand=True)

        left = tk.Frame(container, bg="white", width=300, padx=10, pady=10)
        left.pack(side="left", fill="y", padx=(0, 10))

        right = tk.Frame(container, bg="white")
        right.pack(side="right", fill="both", expand=True)

        # Form
        tk.Label(left, text="QUẢN LÝ PHÒNG BAN", font=("Arial", 12, "bold"), bg="white", fg="#2980b9").pack(pady=10)

        tk.Label(left, text="Mã PB (*):", bg="white", anchor="w").pack(fill="x")
        self.txt_ma = tk.Entry(left);
        self.txt_ma.pack(fill="x", pady=5)

        tk.Label(left, text="Tên PB (*):", bg="white", anchor="w").pack(fill="x")
        self.txt_ten = tk.Entry(left);
        self.txt_ten.pack(fill="x", pady=5)

        tk.Label(left, text="Địa chỉ:", bg="white", anchor="w").pack(fill="x")
        self.txt_dc = tk.Entry(left);
        self.txt_dc.pack(fill="x", pady=5)

        tk.Label(left, text="SĐT:", bg="white", anchor="w").pack(fill="x")
        self.txt_sdt = tk.Entry(left);
        self.txt_sdt.pack(fill="x", pady=5)

        tk.Button(left, text="THÊM", bg="#27ae60", fg="white", pady=5, command=self.them).pack(fill="x", pady=(20, 5))
        tk.Button(left, text="SỬA", bg="#f39c12", fg="white", pady=5, command=self.sua).pack(fill="x", pady=5)
        tk.Button(left, text="XÓA", bg="#c0392b", fg="white", pady=5, command=self.xoa).pack(fill="x", pady=5)
        tk.Button(left, text="LÀM MỚI", bg="#95a5a6", fg="white", pady=5, command=self.clear).pack(fill="x", pady=5)

        # Table
        self.tree = ttk.Treeview(right, columns=("Ma", "Ten", "DC", "SDT"), show="headings")
        self.tree.heading("Ma", text="Mã");
        self.tree.heading("Ten", text="Tên Phòng")
        self.tree.heading("DC", text="Địa chỉ");
        self.tree.heading("SDT", text="SĐT")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<ButtonRelease-1>", self.on_click)

    def load_data(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in fetch_all("SELECT * FROM phongban"):
            self.tree.insert("", "end", values=(r['MaPB'], r['TenPB'], r['DiaChi'], r['SDT']))

    def clear(self):
        self.txt_ma.config(state='normal')
        self.txt_ma.delete(0, tk.END)
        self.txt_ten.delete(0, tk.END)
        self.txt_dc.delete(0, tk.END)
        self.txt_sdt.delete(0, tk.END)

    def them(self):
        ma = self.txt_ma.get().strip()
        ten = self.txt_ten.get().strip()

        if not ma or not ten:
            messagebox.showwarning("Thiếu dữ liệu", "Mã PB và Tên PB không được để trống!")
            return

        # Check trùng
        if fetch_all("SELECT * FROM phongban WHERE MaPB=%s", (ma,)):
            messagebox.showerror("Trùng lặp", f"Mã phòng ban '{ma}' đã tồn tại!")
            return

        if execute_query("INSERT INTO phongban VALUES(%s,%s,%s,%s)",
                         (ma, ten, self.txt_dc.get(), self.txt_sdt.get())):
            self.load_data();
            self.clear();
            messagebox.showinfo("OK", "Đã thêm phòng ban")

    def sua(self):
        ma = self.txt_ma.get().strip()
        if not ma: return

        if execute_query("UPDATE phongban SET TenPB=%s, DiaChi=%s, SDT=%s WHERE MaPB=%s",
                         (self.txt_ten.get(), self.txt_dc.get(), self.txt_sdt.get(), ma)):
            self.load_data();
            self.clear();
            messagebox.showinfo("OK", "Đã cập nhật")

    def xoa(self):
        sel = self.tree.selection()
        if not sel: return
        ma = self.tree.item(sel[0])['values'][0]

        if messagebox.askyesno("Cảnh báo", f"Xóa phòng ban {ma} sẽ xóa luôn nhân viên thuộc phòng này. Tiếp tục?"):
            execute_query("DELETE FROM phongban WHERE MaPB=%s", (ma,))
            self.load_data();
            self.clear()

    def on_click(self, e):
        sel = self.tree.selection()
        if sel:
            r = self.tree.item(sel[0])['values']
            self.clear()
            self.txt_ma.insert(0, r[0])
            self.txt_ma.config(state='disabled')  # Khóa mã không cho sửa
            self.txt_ten.insert(0, r[1])
            self.txt_dc.insert(0, r[2])
            self.txt_sdt.insert(0, r[3])