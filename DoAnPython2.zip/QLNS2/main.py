import tkinter as tk
from tkinter import ttk, messagebox
# Import các class giao diện từ các file con
from nhanvien import NhanVienPage
from phongban import PhongBanPage
from chucvu import ChucVuPage
from hopdong import HopDongPage
from bangluong import BangLuongPage


class HRMApp:
    def __init__(self, user_data):
        self.user = user_data
        self.root = tk.Tk()
        self.root.title("HỆ THỐNG QUẢN LÝ NHÂN SỰ PRO")
        self.root.geometry("1200x700")
        self.root.state("zoomed")  # Full màn hình

        #Tạo Menu
        menubar = tk.Menu(self.root)

        # Tạo menu "Chức năng"
        menu_functions = tk.Menu(menubar, tearoff=0)
        menu_functions.add_command(label="Nhân viên", command=lambda: self.show_frame(NhanVienPage, "NHÂN VIÊN"))
        menu_functions.add_command(label="Phòng ban", command=lambda: self.show_frame(PhongBanPage, "PHÒNG BAN"))
        menu_functions.add_command(label="Chức vụ", command=lambda: self.show_frame(ChucVuPage, "CHỨC VỤ"))
        menu_functions.add_command(label="Hợp đồng", command=lambda: self.show_frame(HopDongPage, "HỢP ĐỒNG"))
        menu_functions.add_command(label="Lương & Thưởng",
                                   command=lambda: self.show_frame(BangLuongPage, "LƯƠNG & THƯỞNG"))

        # Add menu vào thanh menu chính
        menubar.add_cascade(label="Chức năng", menu=menu_functions)


        # Gán menubar vào cửa sổ chính
        self.root.config(menu=menubar)

        # --- STYLE ---
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", rowheight=30, font=("Arial", 10))
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"), background="#bdc3c7", foreground="#2c3e50")

        # --- SIDEBAR (Menu phải) ---
        self.sidebar = tk.Frame(self.root, bg="#2c3e50", width=250)
        self.sidebar.pack(side="right", fill="y")
        self.sidebar.pack_propagate(False)

        # Avatar & Info
        tk.Label(self.sidebar, text="HRM SYSTEM", font=("Helvetica", 18, "bold"), bg="#2c3e50", fg="#ecf0f1").pack(
            pady=(40, 20))
        tk.Label(self.sidebar, text="👤", font=("Arial", 50), bg="#2c3e50", fg="white").pack(pady=(0, 10))

        # Hiển thị Tên (Lấy từ DB)

        # Xử lý tên: Bỏ chữ "Nguyễn Văn" nếu có
        ten_hien_thi = self.user['TenNV'].replace("Nguyễn Văn", "").strip()

        # Nếu lỡ xóa hết thì để mặc định là Admin
        if not ten_hien_thi:
            ten_hien_thi = "Admin"

        tk.Label(self.sidebar, text=ten_hien_thi, font=("Arial", 12, "bold"),
                 bg="#2c3e50", fg="white", wraplength=230).pack(padx=10)
        # ------------------------

        # Hiển thị Vai trò
        role = self.user.get('VaiTro', 'NhanVien')
        tk.Label(self.sidebar, text=f"Chức vụ: {role}", font=("Arial", 9, "italic"),
                 bg="#2c3e50", fg="#bdc3c7").pack(pady=(5, 30))

        # MENU BUTTONS
        self.btn_dict = {}
        menus = [
            ("NHÂN VIÊN", NhanVienPage),
            ("PHÒNG BAN", PhongBanPage),
            ("CHỨC VỤ", ChucVuPage),
            ("HỢP ĐỒNG", HopDongPage),
            ("LƯƠNG & THƯỞNG", BangLuongPage)
        ]

        for text, page_class in menus:
            btn = tk.Button(self.sidebar, text=f"  {text}", font=("Arial", 10, "bold"),
                            bg="#2c3e50", fg="white", bd=0, anchor="w", padx=20, pady=12,
                            activebackground="#34495e", activeforeground="white",
                            command=lambda p=page_class, t=text: self.show_frame(p, t))
            btn.pack(fill="x", pady=1)
            self.btn_dict[text] = btn

        # Logout
        tk.Button(self.sidebar, text="  ĐĂNG XUẤT", font=("Arial", 10, "bold"), bg="#c0392b", fg="white", bd=0,
                  anchor="w", padx=20, pady=12,
                  command=self.logout).pack(side="bottom", fill="x")

        # --- MAIN CONTENT (Bên phải) ---
        self.main_area = tk.Frame(self.root, bg="#ecf0f1")
        self.main_area.pack(side="right", fill="both", expand=True)

        self.lbl_title = tk.Label(self.main_area, text="Trang chủ", font=("Arial", 22, "bold"), bg="#ecf0f1",
                                  fg="#2c3e50")
        self.lbl_title.pack(anchor="w", padx=30, pady=20)

        # Container chứa các trang
        self.container = tk.Frame(self.main_area, bg="#ecf0f1")
        self.container.pack(fill="both", expand=True, padx=30, pady=(0, 30))

        #frame tạo
        self.frames = {}
        for F in (NhanVienPage, PhongBanPage, ChucVuPage, HopDongPage, BangLuongPage):
            page_name = F.__name__
            frame = F(parent=self.container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # Mặc định mở trang Nhân Viên
        self.show_frame(NhanVienPage, "NHÂN VIÊN")
        self.root.mainloop()

    def show_frame(self, page_class, title):
        self.lbl_title.config(text=title)

        # Đổi màu nút active
        for k, btn in self.btn_dict.items():
            if k == title:
                btn.configure(bg="#3498db", text=f"➤ {k}")
            else:
                btn.configure(bg="#2c3e50", text=f"  {k}")

        page_name = page_class.__name__
        frame = self.frames[page_name]
        frame.tkraise()
        if hasattr(frame, "load_data"):
            frame.load_data()

    def logout(self):
        if messagebox.askyesno("Đăng xuất", "Bạn muốn thoát?"):
            self.root.destroy()
            from login_view import LoginApp
            LoginApp()