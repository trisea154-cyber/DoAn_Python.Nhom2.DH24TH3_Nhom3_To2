import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from database import fetch_all, execute_query


class NhanVienPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#ecf0f1")
        self.controller = controller

        # --- FORM NHẬP LIỆU ---
        frm = tk.LabelFrame(self, text="Thông tin nhân viên", bg="white", padx=15, pady=15)
        frm.pack(fill="x", pady=(0, 10))

        frm.grid_columnconfigure(0, minsize=90)
        frm.grid_columnconfigure(1, minsize=120)
        frm.grid_columnconfigure(2, minsize=90)
        frm.grid_columnconfigure(3, weight=1)
        frm.grid_columnconfigure(4, minsize=90)
        frm.grid_columnconfigure(5, minsize=120)
        frm.grid_columnconfigure(6, minsize=120)

        # Dòng 1
        tk.Label(frm, text="Mã NV (*):", bg="white").grid(row=0, column=0, sticky="w")
        self.e_ma = tk.Entry(frm, width=15)
        self.e_ma.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(frm, text="Họ tên (*):", bg="white").grid(row=0, column=2, sticky="w")
        self.e_ten = tk.Entry(frm, width=25)
        self.e_ten.grid(row=0, column=3, padx=5, pady=5)

        tk.Label(frm, text="Ngày sinh:", bg="white").grid(row=0, column=4, sticky="w")
        self.e_ns = DateEntry(frm, date_pattern='yyyy-mm-dd', width=12)
        self.e_ns.grid(row=0, column=5, padx=5, pady=5)

        # Dòng 2
        tk.Label(frm, text="Phòng ban:", bg="white").grid(row=1, column=0, sticky="w")
        self.cb_pb = ttk.Combobox(frm, state="readonly", width=13)
        self.cb_pb.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(frm, text="Chức vụ:", bg="white").grid(row=1, column=2, sticky="w")
        self.cb_cv = ttk.Combobox(frm, state="readonly", width=23)
        self.cb_cv.grid(row=1, column=3, padx=5, pady=5)

        tk.Label(frm, text="User/Pass (*):", bg="white").grid(row=1, column=4, sticky="w")
        self.e_user = tk.Entry(frm, width=12)
        self.e_user.grid(row=1, column=5, padx=5, pady=5)
        self.e_pass = tk.Entry(frm, width=12, show="*")
        self.e_pass.grid(row=1, column=6, padx=5, pady=5)

        # Nút chức năng
        btn_box = tk.Frame(frm, bg="white")
        btn_box.grid(row=2, columnspan=8, pady=10)

        tk.Button(btn_box, text="Làm mới", bg="#95a5a6", fg="white", width=10, command=self.clear_form).pack(side="left", padx=5)
        tk.Button(btn_box, text="Thêm", bg="#2980b9", fg="white", width=10, command=self.them).pack(side="left", padx=5)
        tk.Button(btn_box, text="Sửa", bg="#f39c12", fg="white", width=10, command=self.sua).pack(side="left", padx=5)
        tk.Button(btn_box, text="Xóa", bg="#c0392b", fg="white", width=10, command=self.xoa).pack(side="left", padx=5)

        # --- BẢNG DỮ LIỆU ---
        cols = ("Ma", "Ten", "PB", "CV", "User", "NgaySinh")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")

        # Heading căn giữa
        self.tree.heading("Ma", text="Mã NV", anchor="center")
        self.tree.heading("Ten", text="Họ Tên", anchor="center")
        self.tree.heading("PB", text="Phòng Ban", anchor="center")
        self.tree.heading("CV", text="Chức Vụ", anchor="center")
        self.tree.heading("User", text="Tài khoản", anchor="center")
        self.tree.heading("NgaySinh", text="Ngày Sinh", anchor="center")

        # Căn dữ liệu từng cột sang trái (anchor="w")
        for col in cols:
            self.tree.column(col, anchor="w")

        # Chiều rộng từng cột
        self.tree.column("Ma", width=80)
        self.tree.column("Ten", width=150)
        self.tree.column("PB", width=120)
        self.tree.column("CV", width=120)
        self.tree.column("User", width=100)
        self.tree.column("NgaySinh", width=100)

        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.get_row)

        self.pb_map = {}
        self.cv_map = {}

    # --- LOAD DỮ LIỆU ---
    def load_data(self):
        pbs = fetch_all("SELECT MaPB, TenPB FROM phongban")
        self.pb_map = {r['TenPB']: r['MaPB'] for r in pbs}
        self.cb_pb['values'] = list(self.pb_map.keys())

        cvs = fetch_all("SELECT MaCV, TenCV FROM chucvu")
        self.cv_map = {r['TenCV']: r['MaCV'] for r in cvs}
        self.cb_cv['values'] = list(self.cv_map.keys())

        for i in self.tree.get_children():
            self.tree.delete(i)
        sql = """SELECT n.MaNV, n.TenNV, p.TenPB, c.TenCV, n.TenDangNhap, n.NgaySinh 
                 FROM nhanvien n 
                 LEFT JOIN phongban p ON n.MaPB=p.MaPB 
                 LEFT JOIN chucvu c ON n.MaCV=c.MaCV"""
        for r in fetch_all(sql):
            self.tree.insert("", "end",
                             values=(r['MaNV'], r['TenNV'], r['TenPB'], r['TenCV'], r['TenDangNhap'], r['NgaySinh']))

    # --- CHỌN DÒNG ---
    def get_row(self, event):
        try:
            sel = self.tree.selection()
            if not sel: return
            data = self.tree.item(sel[0], "values")
            self.clear_form()
            self.e_ma.insert(0, data[0])
            self.e_ma.config(state='disabled')
            self.e_ten.insert(0, data[1])
            if data[2]: self.cb_pb.set(data[2])
            if data[3]: self.cb_cv.set(data[3])
            self.e_user.insert(0, data[4])
            try:
                self.e_ns.set_date(data[5])
            except:
                pass
        except:
            pass

    # --- CLEAR FORM ---
    def clear_form(self):
        self.e_ma.config(state='normal')
        self.e_ma.delete(0, tk.END)
        self.e_ten.delete(0, tk.END)
        self.e_user.delete(0, tk.END)
        self.e_pass.delete(0, tk.END)
        self.cb_pb.set('')
        self.cb_cv.set('')
        self.e_ma.focus()

    # --- VALIDATE ---
    def validate(self, is_add=True):
        if not self.e_ma.get().strip() or not self.e_ten.get().strip() or \
           not self.e_user.get().strip() or (is_add and not self.e_pass.get().strip()):
            messagebox.showwarning("Thiếu thông tin", "Vui lòng nhập đầy đủ các trường có dấu (*)")
            return False

        if is_add:
            chk = fetch_all("SELECT * FROM nhanvien WHERE MaNV=%s OR TenDangNhap=%s",
                            (self.e_ma.get(), self.e_user.get()))
            if chk:
                messagebox.showerror("Trùng lặp", "Mã NV hoặc Tên đăng nhập đã tồn tại!")
                return False
        return True

    # --- THÊM NHÂN VIÊN ---
    def them(self):
        if not self.validate(is_add=True): return
        try:
            mpb = self.pb_map.get(self.cb_pb.get())
            mcv = self.cv_map.get(self.cb_cv.get())
            if execute_query(
                "INSERT INTO nhanvien(MaNV,TenNV,MaPB,MaCV,TenDangNhap,MatKhau,NgaySinh) VALUES(%s,%s,%s,%s,%s,%s,%s)",
                (self.e_ma.get(), self.e_ten.get(), mpb, mcv, self.e_user.get(), self.e_pass.get(), self.e_ns.get())
            ):
                self.load_data()
                self.clear_form()
                messagebox.showinfo("Thành công", "Đã thêm nhân viên mới")
        except Exception as e:
            messagebox.showerror("Lỗi SQL", str(e))

    # --- SỬA NHÂN VIÊN ---
    def sua(self):
        if not self.e_ma.get(): return
        try:
            mpb = self.pb_map.get(self.cb_pb.get())
            mcv = self.cv_map.get(self.cb_cv.get())
            new_pass = self.e_pass.get().strip()
            if new_pass:
                sql = "UPDATE nhanvien SET TenNV=%s, MaPB=%s, MaCV=%s, NgaySinh=%s, MatKhau=%s WHERE MaNV=%s"
                params = (self.e_ten.get(), mpb, mcv, self.e_ns.get(), new_pass, self.e_ma.get())
            else:
                sql = "UPDATE nhanvien SET TenNV=%s, MaPB=%s, MaCV=%s, NgaySinh=%s WHERE MaNV=%s"
                params = (self.e_ten.get(), mpb, mcv, self.e_ns.get(), self.e_ma.get())
            if execute_query(sql, params):
                self.load_data()
                self.clear_form()
                messagebox.showinfo("Thành công", "Đã cập nhật thông tin")
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    # --- XÓA NHÂN VIÊN ---
    def xoa(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chưa chọn nhân viên cần xóa")
            return
        manv = self.tree.item(sel[0])['values'][0]
        if manv == 'ADMIN':
            messagebox.showerror("Cấm", "Không thể xóa tài khoản Admin!")
            return
        if messagebox.askyesno("Xác nhận", f"Bạn có chắc muốn xóa nhân viên {manv}?"):
            if execute_query("DELETE FROM nhanvien WHERE MaNV=%s", (manv,)):
                self.load_data()
                self.clear_form()
