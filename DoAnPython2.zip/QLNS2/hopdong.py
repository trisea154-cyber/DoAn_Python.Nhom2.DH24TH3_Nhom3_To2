import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from database import fetch_all, execute_query


class HopDongPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#ecf0f1")
        self.controller = controller

        # --- FORM ---
        frm = tk.LabelFrame(self, text="Hợp đồng lao động", bg="white", padx=10, pady=10)
        frm.pack(fill="x", pady=(0, 10))

        tk.Label(frm, text="Số HĐ (*):", bg="white").grid(row=0, column=0, sticky="w")
        self.e_so = tk.Entry(frm);
        self.e_so.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(frm, text="Nhân viên (*):", bg="white").grid(row=0, column=2, sticky="w")
        self.cb_nv = ttk.Combobox(frm, state="readonly", width=25);
        self.cb_nv.grid(row=0, column=3, padx=5, pady=5)

        tk.Label(frm, text="Loại HĐ:", bg="white").grid(row=0, column=4, sticky="w")
        self.cb_loai = ttk.Combobox(frm, values=["12 Tháng", "36 Tháng", "Vô thời hạn", "Thử việc"], state="readonly")
        self.cb_loai.current(0)
        self.cb_loai.grid(row=0, column=5, padx=5, pady=5)

        tk.Label(frm, text="Ngày BĐ:", bg="white").grid(row=0, column=6, sticky="w")
        self.e_ngay = DateEntry(frm, date_pattern='yyyy-mm-dd');
        self.e_ngay.grid(row=0, column=7, padx=5, pady=5)

        # Buttons
        btn_box = tk.Frame(frm, bg="white")
        btn_box.grid(row=1, columnspan=8, pady=10)
        tk.Button(btn_box, text="Làm mới", command=self.clear, bg="#95a5a6", fg="white", width=10).pack(side="left",
                                                                                                        padx=5)
        tk.Button(btn_box, text="Ký HĐ (Thêm)", command=self.them, bg="#27ae60", fg="white", width=12).pack(side="left",
                                                                                                            padx=5)
        tk.Button(btn_box, text="Cập nhật", command=self.sua, bg="#f39c12", fg="white", width=10).pack(side="left",
                                                                                                       padx=5)
        tk.Button(btn_box, text="Hủy HĐ", command=self.xoa, bg="#c0392b", fg="white", width=10).pack(side="left",
                                                                                                     padx=5)

        # --- TABLE ---
        self.tree = ttk.Treeview(self, columns=("So", "Ten", "Loai", "Ngay"), show="headings")
        self.tree.heading("So", text="Số HĐ");
        self.tree.heading("Ten", text="Nhân viên")
        self.tree.heading("Loai", text="Loại HĐ");
        self.tree.heading("Ngay", text="Ngày Bắt đầu")
        self.tree.pack(fill="both", expand=True)

        self.tree.bind("<<TreeviewSelect>>", self.get_row)
        self.nv_map = {}

    def load_data(self):
        nvs = fetch_all("SELECT MaNV, TenNV FROM nhanvien")
        # Format map: "Tên NV (Mã)" để dễ tìm
        self.nv_map = {f"{r['TenNV']} ({r['MaNV']})": r['MaNV'] for r in nvs}
        self.cb_nv['values'] = list(self.nv_map.keys())

        for i in self.tree.get_children(): self.tree.delete(i)
        sql = "SELECT h.SoHD, n.TenNV, h.LoaiHD, h.NgayBatDau, n.MaNV FROM hopdong h JOIN nhanvien n ON h.MaNV=n.MaNV"
        for r in fetch_all(sql):
            # Lưu MaNV ẩn vào tag hoặc dùng map để tìm lại, ở đây ta hiển thị TenNV
            self.tree.insert("", "end", values=(r['SoHD'], r['TenNV'], r['LoaiHD'], r['NgayBatDau'], r['MaNV']))

    def get_row(self, event):
        try:
            sel = self.tree.selection()
            if not sel: return
            vals = self.tree.item(sel[0])['values']
            # vals: 0=SoHD, 1=TenNV, 2=LoaiHD, 3=Ngay, 4=MaNV (cột ẩn nếu có, ở đây ta lấy từ query)

            self.clear()
            self.e_so.insert(0, vals[0])
            self.e_so.config(state='disabled')

            # Tự động chọn Combobox dựa vào Tên hoặc Mã
            # Do ta lấy thêm cột MaNV ở vị trí index 4 (dù không hiện header nhưng values vẫn có nếu insert đủ)
            target_ma = str(vals[4])
            for k, v in self.nv_map.items():
                if v == target_ma:
                    self.cb_nv.set(k)
                    break

            self.cb_loai.set(vals[2])
            self.e_ngay.set_date(vals[3])
        except:
            pass

    def clear(self):
        self.e_so.config(state='normal')
        self.e_so.delete(0, tk.END)
        self.cb_nv.set('')
        self.cb_loai.current(0)
        self.e_so.focus()

    def them(self):
        if not self.e_so.get() or not self.cb_nv.get():
            messagebox.showwarning("Thiếu tin", "Nhập Số HĐ và chọn Nhân viên!")
            return

        mnv = self.nv_map.get(self.cb_nv.get())
        if execute_query("INSERT INTO hopdong(SoHD, MaNV, LoaiHD, NgayBatDau) VALUES(%s,%s,%s,%s)",
                         (self.e_so.get(), mnv, self.cb_loai.get(), self.e_ngay.get())):
            self.load_data();
            self.clear();
            messagebox.showinfo("OK", "Đã ký hợp đồng")

    def sua(self):
        if not self.e_so.get(): return
        mnv = self.nv_map.get(self.cb_nv.get())
        if execute_query("UPDATE hopdong SET MaNV=%s, LoaiHD=%s, NgayBatDau=%s WHERE SoHD=%s",
                         (mnv, self.cb_loai.get(), self.e_ngay.get(), self.e_so.get())):
            self.load_data();
            self.clear();
            messagebox.showinfo("OK", "Đã cập nhật")

    def xoa(self):
        sel = self.tree.selection()
        if sel and messagebox.askyesno("Xóa", "Hủy hợp đồng này?"):
            execute_query("DELETE FROM hopdong WHERE SoHD=%s", (self.tree.item(sel[0])['values'][0],))
            self.load_data();
            self.clear()